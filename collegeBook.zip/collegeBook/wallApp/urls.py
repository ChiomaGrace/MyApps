from django.urls import path
from . import views

urlpatterns = [
    path('', views.loginPage),
    path('processRegistration', views.processRegistration),
    path('processLogin', views.processLogin),
    path('wall', views.wallMainPage),
    path('processMessage', views.processMessage),
    path('processComments', views.processComments),
    path('like/<messageId>', views.userLikes),
    path('unlike/<messageId>', views.userUnlikes),
    path('user/<userId>', views.userPage),
    path('logout', views.logout)
]